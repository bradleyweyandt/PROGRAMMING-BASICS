// variables to determine if guest may ride coaster
var minimumAge = 10;
var minimumHeight = 42;
