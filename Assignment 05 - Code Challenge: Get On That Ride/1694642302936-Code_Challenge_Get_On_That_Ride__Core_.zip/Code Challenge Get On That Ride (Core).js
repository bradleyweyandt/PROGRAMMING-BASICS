// variables to determine if guest may ride coaster
var minimumAge = 10;
var minimumHeight = 42;
if (minimumHeight >= 42 || minimumAge >= 10){
    console.log("Get on that ride, kiddo!")
}
else {
    console.log("Sorry kiddo. Maybe next year.")
}
